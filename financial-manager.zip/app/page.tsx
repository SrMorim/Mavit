"use client"

import { useState, useMemo, useEffect } from "react"
import { CreditCard, Target, Calendar, Plus, Receipt, DollarSign, TrendingUp } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import SubscriptionManager from "@/components/subscription-manager"
import GoalManager from "@/components/goal-manager"
import ChartsView from "@/components/charts-view"
import ExpenseManager from "@/components/expense-manager"
import EnhancedOverviewChart from "@/components/enhanced-overview-chart"
import { Button } from "@/components/ui/button"
import SettingsPanel from "@/components/settings-panel"
import ExpenseForecast from "@/components/expense-forecast"

interface Subscription {
  id: string
  name: string
  price: number
  category: string
  billingCycle: "monthly" | "yearly"
  nextBilling: string
  status: "active" | "cancelled"
  priority: "high" | "medium" | "low"
}

interface Goal {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  deadline: string
  category: string
}

interface Expense {
  id: string
  description: string
  amount: number
  date: string
  category: string
  type: "recurring" | "one-time" | "fixed"
  frequency?: "daily" | "weekly" | "monthly" | "yearly"
}

export default function FinancialManager() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([])
  const [goals, setGoals] = useState<Goal[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])

  const [recentlyUpdated, setRecentlyUpdated] = useState<Set<string>>(new Set())
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set())
  const [monthlyIncome, setMonthlyIncome] = useState(0)
  // Add state for tracking paid items
  const [paidItems, setPaidItems] = useState<Set<string>>(new Set())

  // Load monthly income from localStorage
  useEffect(() => {
    const savedIncome = localStorage.getItem("monthlyIncome")
    if (savedIncome) {
      setMonthlyIncome(Number.parseFloat(savedIncome))
    }
  }, [])

  // Listen for changes in localStorage (when updated from settings)
  useEffect(() => {
    const handleStorageChange = () => {
      const savedIncome = localStorage.getItem("monthlyIncome")
      if (savedIncome) {
        setMonthlyIncome(Number.parseFloat(savedIncome))
      }
    }

    window.addEventListener("storage", handleStorageChange)

    // Also listen for custom event when settings panel updates income
    const handleIncomeUpdate = () => {
      const savedIncome = localStorage.getItem("monthlyIncome")
      if (savedIncome) {
        setMonthlyIncome(Number.parseFloat(savedIncome))
      }
    }

    window.addEventListener("incomeUpdated", handleIncomeUpdate)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("incomeUpdated", handleIncomeUpdate)
    }
  }, [])

  // Helper function to format date for display (DD/MM/YYYY)
  const formatDateForDisplay = (dateString: string) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    // Add timezone offset to prevent off-by-one day errors
    const adjustedDate = new Date(date.valueOf() + date.getTimezoneOffset() * 60 * 1000)
    return adjustedDate.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  // Memoized calculations for better performance
  const financialSummary = useMemo(() => {
    const activeSubscriptions = subscriptions.filter((sub) => sub.status === "active")
    const currentDate = new Date()
    const currentMonth = currentDate.getMonth()
    const currentYear = currentDate.getFullYear()

    const totalMonthlySubscriptions = activeSubscriptions.reduce((total, sub) => {
      if (sub.billingCycle === "monthly") {
        return total + sub.price
      }
      if (sub.billingCycle === "yearly") {
        const billingDate = new Date(sub.nextBilling)
        if (billingDate.getMonth() === currentMonth && billingDate.getFullYear() === currentYear) {
          return total + sub.price
        }
      }
      return total
    }, 0)

    const getMonthlyExpenseAmount = (expense: Expense) => {
      const expenseDate = new Date(expense.date)

      if (expense.type === "fixed") {
        return expense.amount
      }

      if (expense.type === "one-time") {
        if (expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear) {
          return expense.amount
        }
        return 0
      }

      if (expense.type === "recurring") {
        switch (expense.frequency) {
          case "daily":
            return expense.amount * 30 // Approximation
          case "weekly":
            return expense.amount * 4 // Approximation
          case "monthly":
            return expense.amount
          case "yearly":
            if (expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear) {
              return expense.amount
            }
            return 0
          default:
            return 0
        }
      }
      return 0
    }

    const totalMonthlyExpenses = expenses.reduce((total, expense) => {
      return total + getMonthlyExpenseAmount(expense)
    }, 0)

    const totalMonthlySpending = totalMonthlySubscriptions + totalMonthlyExpenses

    const totalGoalsProgress =
      goals.length > 0
        ? goals.reduce((total, goal) => {
            return total + (goal.currentAmount / goal.targetAmount) * 100
          }, 0) / goals.length
        : 0

    // Calculate breakdown by expense type for the current month
    const fixedExpensesTotal = expenses
      .filter((exp) => exp.type === "fixed")
      .reduce((total, exp) => total + getMonthlyExpenseAmount(exp), 0)

    const recurringExpensesTotal = expenses
      .filter((exp) => exp.type === "recurring")
      .reduce((total, exp) => total + getMonthlyExpenseAmount(exp), 0)

    const currentMonthOneTimeTotal = expenses
      .filter((exp) => exp.type === "one-time")
      .reduce((total, exp) => total + getMonthlyExpenseAmount(exp), 0)

    return {
      totalMonthlySubscriptions,
      totalMonthlyExpenses,
      totalMonthlySpending,
      totalGoalsProgress,
      activeSubscriptionsCount: activeSubscriptions.length,
      expensesCount: expenses.length,
      goalsCount: goals.length,
      fixedExpensesTotal,
      recurringExpensesTotal,
      currentMonthOneTimeTotal,
    }
  }, [subscriptions, expenses, goals])

  // Calculate net income
  const netIncome = monthlyIncome - financialSummary.totalMonthlySpending

  const getNextMonthDate = (currentDate: string): string => {
    const date = new Date(currentDate)
    const currentDay = date.getDate()
    const currentMonth = date.getMonth()
    const currentYear = date.getFullYear()

    let nextMonth = currentMonth + 1
    let nextYear = currentYear

    if (nextMonth > 11) {
      nextMonth = 0
      nextYear += 1
    }

    const lastDayOfNextMonth = new Date(nextYear, nextMonth + 1, 0).getDate()
    const nextDay = Math.min(currentDay, lastDayOfNextMonth)
    const nextDate = new Date(nextYear, nextMonth, nextDay)
    return nextDate.toISOString().split("T")[0]
  }

  const isChargeUpcoming = (billingDate: string, daysThreshold = 20): boolean => {
    const today = new Date()
    const billing = new Date(billingDate)
    const diffTime = billing.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays >= -2 && diffDays <= daysThreshold
  }

  const getUpcomingCharges = () => {
    return subscriptions
      .filter((sub) => sub.status === "active" && isChargeUpcoming(sub.nextBilling))
      .sort((a, b) => {
        const priorityOrder = { high: 0, medium: 1, low: 2 }
        if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
          return priorityOrder[a.priority] - priorityOrder[b.priority]
        }
        return new Date(a.nextBilling).getTime() - new Date(b.nextBilling).getTime()
      })
      .slice(0, 5)
  }

  const handleChargeCheckbox = (subscriptionId: string, isChecked: boolean) => {
    if (isChecked) {
      setCheckedItems((prev) => new Set(prev).add(subscriptionId))

      setSubscriptions((prevSubs) =>
        prevSubs.map((sub) => {
          if (sub.id === subscriptionId) {
            const nextBillingDate = getNextMonthDate(sub.nextBilling)
            return { ...sub, nextBilling: nextBillingDate }
          }
          return sub
        }),
      )

      setRecentlyUpdated((prev) => new Set(prev).add(subscriptionId))

      setTimeout(() => {
        setCheckedItems((prev) => {
          const newSet = new Set(prev)
          newSet.delete(subscriptionId)
          return newSet
        })

        setRecentlyUpdated((prev) => {
          const newSet = new Set(prev)
          newSet.delete(subscriptionId)
          return newSet
        })
      }, 1500)
    }
  }

  const upcomingCharges = getUpcomingCharges()
  const hasAnyData =
    financialSummary.activeSubscriptionsCount > 0 ||
    financialSummary.expensesCount > 0 ||
    financialSummary.goalsCount > 0

  // ENHANCED: Get all current month charges including subscriptions and expenses
  // Enhanced function to get unpaid current month charges
  const getCurrentMonthCharges = () => {
    const currentDate = new Date()
    const currentMonth = currentDate.getMonth()
    const currentYear = currentDate.getFullYear()

    // Get subscriptions due this month (unpaid only)
    const subscriptionCharges = subscriptions
      .filter((sub) => {
        if (sub.status !== "active") return false
        if (paidItems.has(`subscription-${sub.id}`)) return false
        const billingDate = new Date(sub.nextBilling)
        return billingDate.getMonth() === currentMonth && billingDate.getFullYear() === currentYear
      })
      .map((sub) => ({
        id: sub.id,
        type: "subscription" as const,
        description: sub.name,
        amount: sub.price,
        date: sub.nextBilling,
        category: sub.category,
        priority: sub.priority,
        billingCycle: sub.billingCycle,
      }))

    // Get expenses due this month (unpaid only)
    const expenseCharges = expenses
      .filter((expense) => {
        if (paidItems.has(`expense-${expense.id}`)) return false
        const expenseDate = new Date(expense.date)

        // For fixed expenses, show if they're due this month (any year, same month and day)
        if (expense.type === "fixed") {
          return expenseDate.getMonth() === currentMonth
        }

        // For one-time expenses, show if they're exactly in this month and year
        if (expense.type === "one-time") {
          return expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear
        }

        // For recurring expenses, show based on frequency
        if (expense.type === "recurring") {
          const daysDiff = Math.abs(currentDate.getTime() - expenseDate.getTime()) / (1000 * 60 * 60 * 24)

          switch (expense.frequency) {
            case "daily":
              return true // Always show daily expenses
            case "weekly":
              return daysDiff % 7 < 7 // Show if within current week cycle
            case "monthly":
              return expenseDate.getMonth() === currentMonth
            case "yearly":
              return expenseDate.getMonth() === currentMonth && expenseDate.getDate() <= currentDate.getDate() + 30
            default:
              return expenseDate.getMonth() === currentMonth
          }
        }

        return false
      })
      .map((expense) => ({
        id: expense.id,
        type: "expense" as const,
        description: expense.description,
        amount: expense.amount,
        date: expense.date,
        category: expense.category,
        expenseType: expense.type,
        frequency: expense.frequency,
      }))

    // Combine and sort all charges
    const allCharges = [...subscriptionCharges, ...expenseCharges]
      .sort((a, b) => {
        // Sort by due date, with overdue items first
        const dateA = new Date(a.date)
        const dateB = new Date(b.date)
        return dateA.getTime() - dateB.getTime()
      })
      .slice(0, 10) // Limit to 10 items for better UI

    return allCharges
  }

  // Add function to handle payment marking
  const handleMarkAsPaid = (chargeType: "subscription" | "expense", chargeId: string) => {
    const itemKey = `${chargeType}-${chargeId}`

    // Mark as paid
    setPaidItems((prev) => new Set(prev).add(itemKey))

    if (chargeType === "subscription") {
      // Update subscription next billing date
      setSubscriptions((prevSubs) =>
        prevSubs.map((sub) => {
          if (sub.id === chargeId) {
            const [year, month, day] = sub.nextBilling.split("-").map(Number)
            const currentDate = new Date(year, month - 1, day)

            if (sub.billingCycle === "monthly") {
              currentDate.setMonth(currentDate.getMonth() + 1)
              // If the day changed, it means we rolled over. Set to last day of target month.
              if (currentDate.getDate() !== day) {
                currentDate.setDate(0)
              }
            } else {
              // yearly
              currentDate.setFullYear(currentDate.getFullYear() + 1)
            }
            return { ...sub, nextBilling: currentDate.toISOString().split("T")[0] }
          }
          return sub
        }),
      )
    } else {
      // expense
      const expenseToUpdate = expenses.find((e) => e.id === chargeId)
      if (!expenseToUpdate) return

      if (expenseToUpdate.type === "one-time") {
        // Requirement 1: Delete one-time expense
        setExpenses((prevExpenses) => prevExpenses.filter((e) => e.id !== chargeId))
      } else {
        // Handle recurring and fixed expenses
        setExpenses((prevExpenses) =>
          prevExpenses.map((expense) => {
            if (expense.id === chargeId) {
              const [year, month, day] = expense.date.split("-").map(Number)
              const currentDate = new Date(year, month - 1, day)

              if (expense.type === "fixed") {
                // Treat as monthly
                currentDate.setMonth(currentDate.getMonth() + 1)
                if (currentDate.getDate() !== day) {
                  currentDate.setDate(0)
                }
              } else if (expense.type === "recurring") {
                switch (expense.frequency) {
                  case "daily":
                    currentDate.setDate(currentDate.getDate() + 1)
                    break
                  case "weekly":
                    currentDate.setDate(currentDate.getDate() + 7)
                    break
                  case "monthly":
                    currentDate.setMonth(currentDate.getMonth() + 1)
                    if (currentDate.getDate() !== day) {
                      currentDate.setDate(0)
                    }
                    break
                  case "yearly":
                    currentDate.setFullYear(currentDate.getFullYear() + 1)
                    break
                }
              }
              return { ...expense, date: currentDate.toISOString().split("T")[0] }
            }
            return expense
          }),
        )
      }
    }

    // Remove from paid items after a delay to show feedback
    setTimeout(() => {
      setPaidItems((prev) => {
        const newSet = new Set(prev)
        newSet.delete(itemKey)
        return newSet
      })
    }, 1500)
  }

  const getCurrentMonthChargesList = getCurrentMonthCharges()

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <div className="mb-8 animate-fade-in">
          <div className="flex justify-between items-start">
            <div className="animate-slide-in-left">
              <h1 className="text-3xl font-bold tracking-tight">Gerenciador Financeiro</h1>
              <p className="text-muted-foreground">Controle completo das suas finanças pessoais</p>
            </div>
            <div className="animate-slide-in-right">
              <SettingsPanel
                subscriptions={subscriptions}
                goals={goals}
                expenses={expenses}
                setSubscriptions={setSubscriptions}
                setGoals={setGoals}
                setExpenses={setExpenses}
              />
            </div>
          </div>
        </div>

        {/* Enhanced Summary Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card className="card-hover animate-scale-in stagger-1">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Renda Mensal</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600 animate-heartbeat" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">R$ {monthlyIncome.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">
                {monthlyIncome === 0 ? "Configure nas configurações" : "Renda definida"}
              </p>
            </CardContent>
          </Card>

          <Card className="card-hover animate-scale-in stagger-2">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Gastos Mensais</CardTitle>
              <CreditCard className="h-4 w-4 text-red-600 animate-heartbeat" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                R$ {financialSummary.totalMonthlySpending.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">Assinaturas + Fixas + Recorrentes + Pontuais</p>
              <div className="mt-2 space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Assinaturas:</span>
                  <span>R$ {financialSummary.totalMonthlySubscriptions.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Fixas:</span>
                  <span>R$ {financialSummary.fixedExpensesTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Recorrentes:</span>
                  <span>R$ {financialSummary.recurringExpensesTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Pontuais (mês atual):</span>
                  <span>R$ {financialSummary.currentMonthOneTimeTotal.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-hover animate-scale-in stagger-3">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Saldo Líquido</CardTitle>
              <TrendingUp
                className={`h-4 w-4 animate-heartbeat ${netIncome >= 0 ? "text-green-600" : "text-red-600"}`}
              />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${netIncome >= 0 ? "text-green-600" : "text-red-600"}`}>
                R$ {netIncome.toFixed(2)}
              </div>
              <p className="text-xs text-muted-foreground">
                {netIncome >= 0 ? "Saldo positivo" : "Gastos excedem renda"}
              </p>
            </CardContent>
          </Card>

          <Card className="card-hover animate-scale-in stagger-4">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Progresso das Metas</CardTitle>
              <Target className="h-4 w-4 text-blue-600 animate-heartbeat" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{financialSummary.totalGoalsProgress.toFixed(1)}%</div>
              <p className="text-xs text-muted-foreground">{financialSummary.goalsCount} metas ativas</p>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Tabs */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="animate-fade-in grid w-full grid-cols-6 max-w-3xl mx-auto">
            <TabsTrigger value="overview" className="tab-content">
              Visão Geral
            </TabsTrigger>
            <TabsTrigger value="subscriptions" className="tab-content">
              Assinaturas
            </TabsTrigger>
            <TabsTrigger value="expenses" className="tab-content">
              Despesas
            </TabsTrigger>
            <TabsTrigger value="goals" className="tab-content">
              Metas
            </TabsTrigger>
            <TabsTrigger value="charts" className="tab-content">
              Gráficos
            </TabsTrigger>
            <TabsTrigger value="forecast" className="tab-content">
              Previsão
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 tab-content">
            {!hasAnyData ? (
              <div className="text-center py-16 animate-fade-in">
                <CreditCard className="h-16 w-16 mx-auto mb-6 text-muted-foreground opacity-50 animate-bounce" />
                <h3 className="text-xl font-medium mb-3">Bem-vindo ao seu Painel Financeiro!</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  Comece adicionando suas assinaturas, despesas e definindo metas financeiras para ter controle completo
                  das suas finanças.
                </p>
                <div className="flex gap-3 justify-center flex-wrap">
                  <Button className="btn-animate">
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Assinatura
                  </Button>
                  <Button variant="outline" className="btn-animate bg-transparent">
                    <Receipt className="h-4 w-4 mr-2" />
                    Registrar Despesa
                  </Button>
                  <Button variant="outline" className="btn-animate bg-transparent">
                    <Target className="h-4 w-4 mr-2" />
                    Criar Meta
                  </Button>
                </div>
              </div>
            ) : (
              <>
                {/* Monthly Financial Summary */}
                <Card className="card-hover animate-scale-in">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-xl font-semibold">Resumo Financeiro Mensal</CardTitle>
                    <CardDescription className="text-sm text-muted-foreground">Renda vs. Despesas</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Main Income vs Expenses Display */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="text-3xl font-bold">
                          <span className="text-green-600">R$ {monthlyIncome.toFixed(2)}</span>
                          <span className="text-muted-foreground mx-2">/</span>
                          <span className="text-red-600">R$ {financialSummary.totalMonthlySpending.toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground mb-1">Saldo Líquido</p>
                        <p className={`text-2xl font-bold ${netIncome >= 0 ? "text-green-600" : "text-red-600"}`}>
                          R$ {netIncome.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    {/* Usage Percentage */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">
                          Você utilizou{" "}
                          {monthlyIncome > 0
                            ? ((financialSummary.totalMonthlySpending / monthlyIncome) * 100).toFixed(1)
                            : "0.0"}
                          % da sua renda este mês
                        </span>
                      </div>
                      <Progress
                        value={
                          monthlyIncome > 0
                            ? Math.min((financialSummary.totalMonthlySpending / monthlyIncome) * 100, 100)
                            : 0
                        }
                        className="h-2 progress-animate"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Expense Distribution Section */}
                <Card className="card-hover animate-scale-in stagger-1">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-xl font-semibold">Distribuição de Gastos</CardTitle>
                    <CardDescription className="text-sm text-muted-foreground">
                      Como seus gastos estão divididos por categoria
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6 lg:grid-cols-3">
                      {/* Chart Area */}
                      <div className="lg:col-span-2">
                        <EnhancedOverviewChart subscriptions={subscriptions} expenses={expenses} />
                      </div>

                      {/* Summary Panel */}
                      <div className="space-y-4">
                        <Card className="bg-muted/30 border-0">
                          <CardContent className="p-4 space-y-4">
                            <div className="flex justify-between items-center">
                              <span className="text-sm font-medium text-muted-foreground">Renda Mensal</span>
                              <span className="text-lg font-bold text-green-600">R$ {monthlyIncome.toFixed(2)}</span>
                            </div>

                            <div className="flex justify-between items-center">
                              <span className="text-sm font-medium text-muted-foreground">Total de Despesas</span>
                              <span className="text-lg font-bold text-red-600">
                                R$ {financialSummary.totalMonthlySpending.toFixed(2)}
                              </span>
                            </div>

                            <div className="flex justify-between items-center">
                              <span className="text-sm font-medium text-muted-foreground">Metas Ativas</span>
                              <span className="text-lg font-bold text-blue-600">{financialSummary.goalsCount}</span>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Bottom Section - Upcoming Bills and Goal Progress */}
                <div className="grid gap-6 lg:grid-cols-2">
                  {/* Upcoming Bills */}
                  <Card className="card-hover animate-scale-in stagger-2">
                    <CardHeader className="pb-4">
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-5 w-5 text-orange-600" />
                        <CardTitle className="text-lg font-semibold">Próximas Contas</CardTitle>
                      </div>
                      <CardDescription className="text-sm text-muted-foreground">
                        Suas próximas despesas e assinaturas a vencer
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {getCurrentMonthChargesList.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground animate-fade-in">
                          <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p className="text-sm font-medium">Nenhuma conta próxima</p>
                          <p className="text-xs">Todas as contas estão em dia!</p>
                        </div>
                      ) : (
                        <div className="space-y-3 max-h-80 overflow-y-auto">
                          {getCurrentMonthCharges()
                            .slice(0, 5)
                            .map((charge, index) => {
                              const daysUntilDue = Math.ceil(
                                (new Date(charge.date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24),
                              )
                              const isOverdue = daysUntilDue < 0
                              const isDueSoon = daysUntilDue <= 3 && daysUntilDue >= 0
                              const itemKey = `${charge.type}-${charge.id}`
                              const isPaid = paidItems.has(itemKey)

                              const typeColors = {
                                subscription: "border-l-blue-500",
                                expense:
                                  charge.expenseType === "fixed"
                                    ? "border-l-purple-500"
                                    : charge.expenseType === "recurring"
                                      ? "border-l-blue-500"
                                      : "border-l-green-500",
                              }

                              return (
                                <div
                                  key={`${charge.type}-${charge.id}`}
                                  className={`flex items-center gap-3 p-3 rounded-lg border-l-4 border transition-all duration-300 animate-fade-in ${
                                    typeColors[charge.type]
                                  } hover:bg-gray-50 dark:hover:bg-gray-800 ${isPaid ? "opacity-60 bg-green-50 dark:bg-green-950/20" : ""}`}
                                  style={{ animationDelay: `${index * 0.1}s` }}
                                >
                                  {/* Checkbox */}
                                  <div className="flex-shrink-0">
                                    <input
                                      type="checkbox"
                                      checked={isPaid}
                                      onChange={(e) => {
                                        if (e.target.checked) {
                                          handleMarkAsPaid(charge.type, charge.id)
                                        }
                                      }}
                                      className="w-4 h-4 text-green-600 bg-gray-100 border-gray-300 rounded focus:ring-green-500 focus:ring-2 cursor-pointer"
                                      disabled={isPaid}
                                    />
                                  </div>

                                  <div className="flex-1 min-w-0">
                                    <p
                                      className={`font-medium truncate ${isPaid ? "line-through text-muted-foreground" : ""}`}
                                    >
                                      {charge.description}
                                      {isPaid && <span className="ml-2 text-green-600 text-sm">✓</span>}
                                    </p>
                                    <div className="flex items-center space-x-2 mt-1">
                                      <p className="text-sm text-muted-foreground">
                                        {formatDateForDisplay(charge.date)}
                                      </p>
                                      {daysUntilDue >= 0 && !isPaid && (
                                        <span className="text-xs text-muted-foreground">
                                          ({daysUntilDue === 0 ? "hoje" : `${daysUntilDue} dias`})
                                        </span>
                                      )}
                                      {isOverdue && !isPaid && (
                                        <Badge variant="destructive" className="text-xs">
                                          Vencido
                                        </Badge>
                                      )}
                                      {isDueSoon && !isOverdue && !isPaid && (
                                        <Badge variant="secondary" className="text-xs bg-orange-100 text-orange-800">
                                          Urgente
                                        </Badge>
                                      )}
                                    </div>
                                  </div>
                                  <Badge
                                    variant="outline"
                                    className={`font-medium flex-shrink-0 ${isPaid ? "opacity-60" : ""}`}
                                  >
                                    R$ {charge.amount.toFixed(2)}
                                  </Badge>
                                </div>
                              )
                            })}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Goal Progress */}
                  <Card className="card-hover animate-scale-in stagger-3">
                    <CardHeader className="pb-4">
                      <div className="flex items-center space-x-2">
                        <Target className="h-5 w-5 text-blue-600" />
                        <CardTitle className="text-lg font-semibold">Progresso das Metas</CardTitle>
                      </div>
                      <CardDescription className="text-sm text-muted-foreground">
                        Acompanhe o andamento das suas metas financeiras
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {goals.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground animate-fade-in">
                          <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p className="text-sm font-medium">Nenhuma meta definida</p>
                          <p className="text-xs">Crie metas para acompanhar seu progresso!</p>
                        </div>
                      ) : (
                        <div className="space-y-4 max-h-80 overflow-y-auto">
                          {goals.slice(0, 4).map((goal, index) => {
                            const progress = (goal.currentAmount / goal.targetAmount) * 100
                            const isCompleted = progress >= 100

                            return (
                              <div
                                key={goal.id}
                                className={`space-y-3 p-3 rounded-lg border transition-all duration-300 animate-fade-in ${
                                  isCompleted
                                    ? "bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800"
                                    : "bg-muted/30"
                                }`}
                                style={{ animationDelay: `${index * 0.1}s` }}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-2">
                                    <p className="font-medium">{goal.name}</p>
                                    {isCompleted && <span className="text-green-600 text-sm">✓</span>}
                                  </div>
                                  <p
                                    className={`text-sm font-medium ${isCompleted ? "text-green-600" : "text-muted-foreground"}`}
                                  >
                                    {progress.toFixed(1)}%
                                  </p>
                                </div>
                                <Progress
                                  value={Math.min(progress, 100)}
                                  className={`h-2 progress-animate ${isCompleted ? "bg-green-100" : ""}`}
                                />
                                <div className="flex justify-between items-center text-xs text-muted-foreground">
                                  <span>R$ {goal.currentAmount.toFixed(2)}</span>
                                  <span>R$ {goal.targetAmount.toFixed(2)}</span>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                  Prazo: {formatDateForDisplay(goal.deadline)}
                                </p>
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </>
            )}
          </TabsContent>

          <TabsContent value="subscriptions" className="tab-content">
            <SubscriptionManager subscriptions={subscriptions} setSubscriptions={setSubscriptions} />
          </TabsContent>

          <TabsContent value="expenses" className="tab-content">
            <ExpenseManager expenses={expenses} setExpenses={setExpenses} />
          </TabsContent>

          <TabsContent value="goals" className="tab-content">
            <GoalManager goals={goals} setGoals={setGoals} />
          </TabsContent>

          <TabsContent value="charts" className="tab-content">
            <ChartsView subscriptions={subscriptions} goals={goals} expenses={expenses} monthlyIncome={monthlyIncome} />
          </TabsContent>

          <TabsContent value="forecast" className="tab-content">
            <ExpenseForecast subscriptions={subscriptions} expenses={expenses} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
