"use client"

import type React from "react"

import { useState, useEffect } from "react"
import {
  Settings,
  Download,
  Upload,
  Moon,
  Sun,
  Monitor,
  X,
  Check,
  Loader2,
  FileText,
  AlertTriangle,
  DollarSign,
} from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { useToast } from "@/hooks/use-toast"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"

interface SettingsPanelProps {
  subscriptions: any[]
  goals: any[]
  expenses: any[]
  setSubscriptions: (data: any[]) => void
  setGoals: (data: any[]) => void
  setExpenses: (data: any[]) => void
}

export default function SettingsPanel({
  subscriptions,
  goals,
  expenses,
  setSubscriptions,
  setGoals,
  setExpenses,
}: SettingsPanelProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isExporting, setIsExporting] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [exportProgress, setExportProgress] = useState(0)
  const [importProgress, setImportProgress] = useState(0)
  const [exportSuccess, setExportSuccess] = useState(false)
  const [importSuccess, setImportSuccess] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [monthlyIncome, setMonthlyIncome] = useState(0)
  const [isSavingIncome, setIsSavingIncome] = useState(false)
  const [incomeSuccess, setIncomeSuccess] = useState(false)
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()

  // Load monthly income from localStorage on component mount
  useEffect(() => {
    const savedIncome = localStorage.getItem("monthlyIncome")
    if (savedIncome) {
      setMonthlyIncome(Number.parseFloat(savedIncome))
    }
  }, [])

  const saveMonthlyIncome = async () => {
    setIsSavingIncome(true)
    setIncomeSuccess(false)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Save to localStorage
    localStorage.setItem("monthlyIncome", monthlyIncome.toString())

    setIncomeSuccess(true)
    toast({
      title: "✅ Renda mensal salva!",
      description: `Renda mensal definida como R$ ${monthlyIncome.toFixed(2)}`,
    })

    setTimeout(() => {
      setIsSavingIncome(false)
      setIncomeSuccess(false)
    }, 1500)
  }

  const exportData = async () => {
    setIsExporting(true)
    setExportProgress(0)
    setExportSuccess(false)

    try {
      // Simulate progress for better UX
      const progressSteps = [20, 40, 60, 80, 100]
      for (const step of progressSteps) {
        setExportProgress(step)
        await new Promise((resolve) => setTimeout(resolve, 150))
      }

      const data = {
        subscriptions,
        goals,
        expenses,
        monthlyIncome,
        exportDate: new Date().toISOString(),
        version: "1.0",
      }

      const dataStr = JSON.stringify(data, null, 2)
      const dataBlob = new Blob([dataStr], { type: "application/json" })
      const url = URL.createObjectURL(dataBlob)

      const link = document.createElement("a")
      link.href = url
      link.download = `financeiro-backup-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)

      setExportSuccess(true)
      toast({
        title: "✅ Dados exportados com sucesso!",
        description: "O arquivo de backup foi baixado para seu dispositivo.",
      })

      // Reset success state after animation
      setTimeout(() => {
        setExportSuccess(false)
        setExportProgress(0)
      }, 2000)
    } catch (error) {
      toast({
        title: "❌ Erro ao exportar dados",
        description: "Ocorreu um erro durante a exportação. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const importData = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsImporting(true)
    setImportProgress(0)
    setImportSuccess(false)

    try {
      // Simulate progress for better UX
      const progressSteps = [25, 50, 75, 100]
      for (const step of progressSteps) {
        setImportProgress(step)
        await new Promise((resolve) => setTimeout(resolve, 200))
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const importedData = JSON.parse(e.target?.result as string)

          // Validate data structure
          if (!importedData.subscriptions || !importedData.goals || !importedData.expenses) {
            throw new Error("Formato de arquivo inválido")
          }

          // Update state with imported data
          setSubscriptions(importedData.subscriptions || [])
          setGoals(importedData.goals || [])
          setExpenses(importedData.expenses || [])

          // Import monthly income if available
          if (importedData.monthlyIncome !== undefined) {
            setMonthlyIncome(importedData.monthlyIncome)
            localStorage.setItem("monthlyIncome", importedData.monthlyIncome.toString())
          }

          setImportSuccess(true)
          toast({
            title: "✅ Dados importados com sucesso!",
            description: `Backup de ${new Date(importedData.exportDate).toLocaleDateString("pt-BR")} foi restaurado.`,
          })

          // Reset success state after animation
          setTimeout(() => {
            setImportSuccess(false)
            setImportProgress(0)
          }, 2000)
        } catch (error) {
          toast({
            title: "❌ Erro ao importar dados",
            description: "Verifique se o arquivo está no formato correto.",
            variant: "destructive",
          })
        }
      }
      reader.readAsText(file)
    } catch (error) {
      toast({
        title: "❌ Erro ao processar arquivo",
        description: "Não foi possível processar o arquivo selecionado.",
        variant: "destructive",
      })
    } finally {
      setIsImporting(false)
    }

    // Reset input
    event.target.value = ""
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setDragActive(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setDragActive(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragActive(false)

    const files = e.dataTransfer.files
    if (files.length > 0) {
      const file = files[0]
      if (file.type === "application/json" || file.name.endsWith(".json")) {
        // Create a fake event to reuse the importData function
        const fakeEvent = {
          target: { files: [file] },
        } as React.ChangeEvent<HTMLInputElement>
        importData(fakeEvent)
      } else {
        toast({
          title: "❌ Tipo de arquivo inválido",
          description: "Por favor, selecione um arquivo JSON válido.",
          variant: "destructive",
        })
      }
    }
  }

  const clearAllData = () => {
    if (window.confirm("Tem certeza que deseja limpar todos os dados? Esta ação não pode ser desfeita.")) {
      setSubscriptions([])
      setGoals([])
      setExpenses([])
      setMonthlyIncome(0)
      localStorage.removeItem("monthlyIncome")

      toast({
        title: "🗑️ Dados limpos",
        description: "Todos os dados foram removidos com sucesso.",
      })
    }
  }

  const getDataSummary = () => {
    return {
      subscriptions: subscriptions.length,
      goals: goals.length,
      expenses: expenses.length,
      total: subscriptions.length + goals.length + expenses.length,
    }
  }

  const summary = getDataSummary()

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="relative bg-transparent hover:bg-accent transition-all duration-200 hover:scale-105"
        >
          <Settings className="h-[1.2rem] w-[1.2rem] transition-transform duration-200 hover:rotate-90" />
          <span className="sr-only">Configurações</span>
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Configurações
          </SheetTitle>
          <SheetDescription>Gerencie suas preferências e dados do aplicativo</SheetDescription>
        </SheetHeader>

        <div className="space-y-6 py-6">
          {/* Theme Settings */}
          <Card className="transition-all duration-200 hover:shadow-md">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Monitor className="h-5 w-5" />
                Tema da Interface
              </CardTitle>
              <CardDescription>Escolha entre modo claro, escuro ou automático</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <Button
                  variant={theme === "light" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTheme("light")}
                  className="flex items-center gap-2 transition-all duration-200 hover:scale-105"
                >
                  <Sun className="h-4 w-4" />
                  Claro
                </Button>
                <Button
                  variant={theme === "dark" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTheme("dark")}
                  className="flex items-center gap-2 transition-all duration-200 hover:scale-105"
                >
                  <Moon className="h-4 w-4" />
                  Escuro
                </Button>
                <Button
                  variant={theme === "system" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTheme("system")}
                  className="flex items-center gap-2 transition-all duration-200 hover:scale-105"
                >
                  <Monitor className="h-4 w-4" />
                  Auto
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                O tema selecionado será salvo e aplicado em todas as sessões
              </p>
            </CardContent>
          </Card>

          <Separator />

          {/* Income Management */}
          <Card className="transition-all duration-200 hover:shadow-md">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Renda Mensal
              </CardTitle>
              <CardDescription>Configure sua renda mensal para cálculos financeiros</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <Label htmlFor="monthlyIncome" className="text-sm font-medium">
                    Renda Mensal (R$)
                  </Label>
                  <Input
                    id="monthlyIncome"
                    type="number"
                    step="0.01"
                    value={monthlyIncome}
                    onChange={(e) => setMonthlyIncome(Number.parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    className="mt-1 input-focus"
                  />
                </div>
                <Button
                  onClick={saveMonthlyIncome}
                  disabled={isSavingIncome}
                  className={`btn-animate ${incomeSuccess ? "success-glow" : ""}`}
                >
                  {isSavingIncome ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Salvando...
                    </>
                  ) : incomeSuccess ? (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Salvo!
                    </>
                  ) : (
                    "Salvar"
                  )}
                </Button>
              </div>
              <div className="p-3 bg-muted/30 rounded border-l-2 border-blue-500">
                <p className="text-sm text-muted-foreground">
                  💡 Sua renda mensal será usada para calcular o saldo líquido e análises financeiras
                </p>
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Enhanced Data Management */}
          <Card className="transition-all duration-200 hover:shadow-md">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Gerenciamento de Dados
              </CardTitle>
              <CardDescription>Importe, exporte ou limpe seus dados financeiros</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Enhanced Data Summary */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-gradient-to-r from-muted/30 to-muted/50 rounded-lg border transition-all duration-200 hover:shadow-sm">
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                      Assinaturas:
                    </span>
                    <Badge variant="secondary" className="animate-in fade-in duration-300">
                      {summary.subscriptions}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      Metas:
                    </span>
                    <Badge variant="secondary" className="animate-in fade-in duration-300 delay-100">
                      {summary.goals}
                    </Badge>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-sm">
                    <span className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                      Despesas:
                    </span>
                    <Badge variant="secondary" className="animate-in fade-in duration-300 delay-200">
                      {summary.expenses}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center text-sm font-medium">
                    <span className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
                      Total:
                    </span>
                    <Badge className="animate-in fade-in duration-300 delay-300">{summary.total}</Badge>
                  </div>
                </div>
              </div>

              {/* Enhanced Export/Import Actions */}
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium mb-3 block">Backup dos Dados</Label>

                  {/* Export Section */}
                  <div className="space-y-3">
                    <div className="relative">
                      <Button
                        onClick={exportData}
                        disabled={isExporting}
                        className={`w-full transition-all duration-300 ${
                          exportSuccess ? "bg-green-600 hover:bg-green-700" : "hover:scale-[1.02] hover:shadow-md"
                        }`}
                        variant={exportSuccess ? "default" : "outline"}
                      >
                        {isExporting ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Exportando...
                          </>
                        ) : exportSuccess ? (
                          <>
                            <Check className="h-4 w-4 mr-2" />
                            Exportado com Sucesso!
                          </>
                        ) : (
                          <>
                            <Download className="h-4 w-4 mr-2" />
                            Exportar JSON
                          </>
                        )}
                      </Button>

                      {/* Export Progress */}
                      {isExporting && (
                        <div className="mt-2 space-y-1">
                          <Progress value={exportProgress} className="h-2" />
                          <p className="text-xs text-muted-foreground text-center">
                            Preparando backup... {exportProgress}%
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Import Section with Drag & Drop */}
                    <div className="space-y-2">
                      <div
                        className={`relative border-2 border-dashed rounded-lg p-4 transition-all duration-300 ${
                          dragActive
                            ? "border-primary bg-primary/5 scale-[1.02]"
                            : "border-muted-foreground/25 hover:border-muted-foreground/50"
                        }`}
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                      >
                        <input
                          type="file"
                          accept=".json"
                          onChange={importData}
                          className="hidden"
                          id="import-file"
                          disabled={isImporting}
                        />

                        <div className="text-center space-y-2">
                          {dragActive ? (
                            <div className="animate-in fade-in duration-200">
                              <Upload className="h-8 w-8 mx-auto text-primary animate-bounce" />
                              <p className="text-sm font-medium text-primary">Solte o arquivo aqui!</p>
                            </div>
                          ) : (
                            <>
                              <Upload className="h-6 w-6 mx-auto text-muted-foreground" />
                              <div className="space-y-1">
                                <p className="text-sm text-muted-foreground">Arraste um arquivo JSON aqui ou</p>
                                <Button
                                  onClick={() => document.getElementById("import-file")?.click()}
                                  disabled={isImporting}
                                  variant="ghost"
                                  size="sm"
                                  className={`text-primary hover:text-primary/80 transition-all duration-200 ${
                                    importSuccess ? "text-green-600" : ""
                                  }`}
                                >
                                  {isImporting ? (
                                    <>
                                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                      Importando...
                                    </>
                                  ) : importSuccess ? (
                                    <>
                                      <Check className="h-4 w-4 mr-2" />
                                      Importado!
                                    </>
                                  ) : (
                                    "clique para selecionar"
                                  )}
                                </Button>
                              </div>
                            </>
                          )}
                        </div>

                        {/* Import Progress */}
                        {isImporting && (
                          <div className="mt-3 space-y-1">
                            <Progress value={importProgress} className="h-2" />
                            <p className="text-xs text-muted-foreground text-center">
                              Processando dados... {importProgress}%
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-muted-foreground mt-3 p-2 bg-muted/30 rounded border-l-2 border-blue-500">
                    💡 Use o backup para sincronizar dados entre dispositivos ou criar cópias de segurança
                  </p>
                </div>

                <Separator />

                {/* Enhanced Danger Zone */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium text-destructive flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Zona de Perigo
                  </Label>
                  <div className="p-3 border border-destructive/20 rounded-lg bg-destructive/5">
                    <Button
                      onClick={clearAllData}
                      variant="destructive"
                      size="sm"
                      className="w-full transition-all duration-200 hover:scale-[1.02] hover:shadow-md"
                    >
                      <X className="h-4 w-4 mr-2" />
                      Limpar Todos os Dados
                    </Button>
                    <p className="text-xs text-muted-foreground mt-2 text-center">
                      ⚠️ Esta ação removerá permanentemente todos os seus dados
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Enhanced App Info */}
          <Card className="transition-all duration-200 hover:shadow-md">
            <CardHeader>
              <CardTitle className="text-lg">Sobre o Aplicativo</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Versão:</span>
                    <Badge variant="outline" className="font-mono">
                      1.0.0
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Última atualização:</span>
                    <span className="font-medium">{new Date().toLocaleDateString("pt-BR")}</span>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="text-center space-y-1">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/40 rounded-full flex items-center justify-center mx-auto">
                      <Settings className="h-6 w-6 text-primary" />
                    </div>
                    <p className="text-xs text-muted-foreground">Financeiro</p>
                  </div>
                </div>
              </div>
              <Separator />
              <p className="text-xs text-muted-foreground text-center py-2 bg-muted/30 rounded">
                💰 Gerenciador Financeiro - Controle completo das suas finanças pessoais
              </p>
            </CardContent>
          </Card>
        </div>
      </SheetContent>
    </Sheet>
  )
}
