"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { ChartContainer } from "@/components/ui/chart"

interface Subscription {
  id: string
  name: string
  price: number
  category: string
  billingCycle: "monthly" | "yearly"
  nextBilling: string
  status: "active" | "cancelled"
  priority: "high" | "medium" | "low"
}

interface Expense {
  id: string
  description: string
  amount: number
  date: string
  category: string
  type: "recurring" | "one-time" | "fixed"
  frequency?: "daily" | "weekly" | "monthly" | "yearly"
}

interface EnhancedOverviewChartProps {
  subscriptions: Subscription[]
  expenses: Expense[]
}

export default function EnhancedOverviewChart({ subscriptions, expenses }: EnhancedOverviewChartProps) {
  const getMonthlyExpenseAmount = (expense: Expense) => {
    if (expense.type === "fixed") {
      return expense.amount
    }

    if (expense.type === "one-time") {
      // Check if the expense date is in the current month
      const expenseDate = new Date(expense.date)
      const currentDate = new Date()

      if (
        expenseDate.getMonth() === currentDate.getMonth() &&
        expenseDate.getFullYear() === currentDate.getFullYear()
      ) {
        return expense.amount
      }
      return 0
    }

    switch (expense.frequency) {
      case "daily":
        return expense.amount * 30
      case "weekly":
        return expense.amount * 4
      case "monthly":
        return expense.amount
      case "yearly":
        return expense.amount / 12
      default:
        return expense.amount
    }
  }

  // Calculate monthly subscription spending by category
  const subscriptionSpending = subscriptions
    .filter((sub) => sub.status === "active")
    .reduce(
      (acc, sub) => {
        const monthlyPrice = sub.billingCycle === "monthly" ? sub.price : sub.price / 12
        const category = `Assinaturas - ${sub.category}`
        acc[category] = (acc[category] || 0) + monthlyPrice
        return acc
      },
      {} as Record<string, number>,
    )

  // Calculate monthly expense spending by category and type
  const expenseSpending = expenses.reduce(
    (acc, expense) => {
      const monthlyAmount = getMonthlyExpenseAmount(expense)
      if (monthlyAmount > 0) {
        const typeLabel = expense.type === "fixed" ? "Fixas" : expense.type === "recurring" ? "Recorrentes" : "Pontuais"
        const category = `${typeLabel} - ${expense.category}`
        acc[category] = (acc[category] || 0) + monthlyAmount
      }
      return acc
    },
    {} as Record<string, number>,
  )

  // Combine all spending
  const allSpending = { ...subscriptionSpending, ...expenseSpending }
  const totalSpending = Object.values(allSpending).reduce((sum, amount) => sum + amount, 0)

  // Prepare data for chart
  const chartData = Object.entries(allSpending)
    .map(([category, amount], index) => ({
      name: category,
      value: amount,
      percentage: ((amount / totalSpending) * 100).toFixed(1),
      fill: `hsl(var(--chart-${(index % 5) + 1}))`,
    }))
    .sort((a, b) => b.value - a.value)

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg">
          <p className="font-medium">{data.name}</p>
          <p className="text-sm text-muted-foreground">
            R$ {data.value.toFixed(2)} ({data.percentage}%)
          </p>
        </div>
      )
    }
    return null
  }

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Distribuição de Gastos</CardTitle>
          <CardDescription>Visão geral dos seus gastos mensais por categoria</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
              <div className="w-8 h-8 bg-muted-foreground/20 rounded-full"></div>
            </div>
            <p className="text-sm text-muted-foreground">
              Adicione assinaturas ou despesas para visualizar a distribuição de gastos
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Distribuição de Gastos</CardTitle>
        <CardDescription>
          Visão geral dos seus gastos mensais por categoria (Total: R$ {totalSpending.toFixed(2)})
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={{
            spending: {
              label: "Gastos",
              color: "hsl(var(--chart-1))",
            },
          }}
          className="aspect-square max-h-[400px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                outerRadius={120}
                dataKey="value"
                label={({ name, percentage }) => `${percentage}%`}
                labelLine={false}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </ChartContainer>
        <div className="mt-6 space-y-2">
          {chartData.map((item, index) => (
            <div key={index} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.fill }}></div>
                <span>{item.name}</span>
              </div>
              <div className="text-right">
                <span className="font-medium">R$ {item.value.toFixed(2)}</span>
                <span className="text-muted-foreground ml-2">({item.percentage}%)</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
