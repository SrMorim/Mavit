"use client"

import * as React from "react"
import { useEffect, useState } from "react"

import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

/** Convert an ISO date (YYYY-MM-DD) to Brazilian format (DD/MM/YYYY) */
function isoToBr(iso: string): string {
  if (!iso) return ""
  const [y, m, d] = iso.split("-")
  return `${d}/${m}/${y}`
}

/** Convert a Brazilian date (DD/MM/YYYY) to ISO (YYYY-MM-DD) */
function brToIso(br: string): string {
  const [d, m, y] = br.split("/")
  if (!d || !m || !y) return ""
  return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`
}

/** Validate a Brazilian date string */
function isValidBrDate(value: string): boolean {
  const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/
  if (!regex.test(value)) return false

  const [, dd, mm, yyyy] = value.match(regex)!
  const date = new Date(Number(yyyy), Number(mm) - 1, Number(dd))
  return date.getFullYear() === Number(yyyy) && date.getMonth() === Number(mm) - 1 && date.getDate() === Number(dd)
}

/* ------------------------------------------------------------------ */
/* Component                                                          */
/* ------------------------------------------------------------------ */

export interface DateInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange"> {
  /** ISO date string kept in state (YYYY-MM-DD) */
  value: string
  /** Called with an ISO date once the user enters a valid date */
  onChange: (isoDate: string) => void
}

/**
 * DateInput
 *
 * A masked input that:
 * • Displays DD/MM/YYYY to the user
 * • Accepts only numbers & slashes
 * • Validates the date
 * • Emits ISO (YYYY-MM-DD) to parent components
 */
export const DateInput = React.forwardRef<HTMLInputElement, DateInputProps>(
  ({ value, onChange, className, ...rest }, ref) => {
    const [displayValue, setDisplayValue] = useState<string>(isoToBr(value))

    /* Keep local display value in sync with external value */
    useEffect(() => {
      setDisplayValue(isoToBr(value))
    }, [value])

    /* Handle user typing */
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      /* Keep only digits & “/” and limit length */
      const raw = e.target.value.replace(/[^\d/]/g, "").slice(0, 10)

      /* Auto-insert slashes (DD/MM/YYYY) */
      let formatted = raw
      if (raw.length > 2 && raw[2] !== "/") formatted = raw.slice(0, 2) + "/" + raw.slice(2)
      if (raw.length > 5 && raw[5] !== "/") formatted = formatted.slice(0, 5) + "/" + formatted.slice(5)

      setDisplayValue(formatted)

      /* If the date is complete & valid ⇒ emit ISO value */
      if (isValidBrDate(formatted)) {
        onChange(brToIso(formatted))
      } else if (formatted.length < 10) {
        /* Allow parent to clear value when user deletes */
        onChange("")
      }
    }

    return (
      <Input
        ref={ref}
        value={displayValue}
        onChange={handleChange}
        placeholder="DD/MM/AAAA"
        className={cn(className)}
        {...rest}
      />
    )
  },
)

DateInput.displayName = "DateInput"
