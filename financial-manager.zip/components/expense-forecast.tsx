"use client"

import { useMemo, useState, useEffect } from "react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"
import { CalendarRange, Filter, TrendingUp, PackageOpen } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

interface Subscription {
  id: string
  name: string
  price: number
  category: string
  billingCycle: "monthly" | "yearly"
  status: "active" | "cancelled"
}

interface Expense {
  id: string
  description: string
  amount: number
  date: string
  category: string
  type: "recurring" | "one-time" | "fixed"
  frequency?: "daily" | "weekly" | "monthly" | "yearly"
}

interface ExpenseForecastProps {
  subscriptions: Subscription[]
  expenses: Expense[]
}

export default function ExpenseForecast({ subscriptions, expenses }: ExpenseForecastProps) {
  const [forecastMonths, setForecastMonths] = useState(6)
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])

  const allCategories = useMemo(() => {
    const categories = new Set<string>()
    subscriptions.filter((s) => s.status === "active").forEach((s) => categories.add(s.category))
    expenses.forEach((e) => categories.add(e.category))
    return Array.from(categories).sort()
  }, [subscriptions, expenses])

  useEffect(() => {
    setSelectedCategories(allCategories)
  }, [allCategories])

  const handleCategoryChange = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const projectedData = useMemo(() => {
    const data = []
    const recurringItems: (Subscription | Expense)[] = []
    const futureOneTimeExpensesByMonth: { [key: string]: Expense[] } = {}

    const activeSubscriptions = subscriptions.filter(
      (s) => s.status === "active" && selectedCategories.includes(s.category),
    )
    const recurringAndFixedExpenses = expenses.filter(
      (e) => (e.type === "recurring" || e.type === "fixed") && selectedCategories.includes(e.category),
    )
    const oneTimeExpenses = expenses.filter((e) => e.type === "one-time" && selectedCategories.includes(e.category))

    recurringItems.push(...activeSubscriptions, ...recurringAndFixedExpenses)

    const today = new Date()
    const currentUtcYear = today.getUTCFullYear()
    const currentUtcMonth = today.getUTCMonth()

    for (let i = 0; i < forecastMonths; i++) {
      const forecastDate = new Date(Date.UTC(currentUtcYear, currentUtcMonth + i, 1))
      const forecastMonth = forecastDate.getUTCMonth()
      const forecastYear = forecastDate.getUTCFullYear()
      const monthName = new Intl.DateTimeFormat("default", {
        month: "short",
        year: "2-digit",
        timeZone: "UTC",
      }).format(forecastDate)

      let monthlyTotal = 0
      futureOneTimeExpensesByMonth[monthName] = []

      // 1. Add recurring subscriptions
      activeSubscriptions.forEach((sub) => {
        if (sub.billingCycle === "monthly") {
          monthlyTotal += sub.price
        } else if (sub.billingCycle === "yearly") {
          monthlyTotal += sub.price / 12
        }
      })

      // 2. Add recurring and fixed expenses
      recurringAndFixedExpenses.forEach((exp) => {
        if (exp.type === "fixed") {
          monthlyTotal += exp.amount
        } else if (exp.type === "recurring") {
          switch (exp.frequency) {
            case "daily":
              monthlyTotal += exp.amount * 30
              break
            case "weekly":
              monthlyTotal += exp.amount * 4
              break
            case "monthly":
              monthlyTotal += exp.amount
              break
            case "yearly":
              monthlyTotal += exp.amount / 12
              break
          }
        }
      })

      // 3. Add one-time expenses for the specific month
      oneTimeExpenses.forEach((exp) => {
        const expenseDate = new Date(exp.date) // YYYY-MM-DD is parsed as UTC
        if (expenseDate.getUTCMonth() === forecastMonth && expenseDate.getUTCFullYear() === forecastYear) {
          monthlyTotal += exp.amount
          futureOneTimeExpensesByMonth[monthName].push(exp)
        }
      })

      data.push({
        month: monthName,
        total: monthlyTotal,
      })
    }

    return { forecast: data, recurringItems, futureOneTimeExpensesByMonth }
  }, [subscriptions, expenses, forecastMonths, selectedCategories])

  const totalProjected = projectedData.forecast.reduce((sum, month) => sum + month.total, 0)
  const averageMonthly = projectedData.forecast.length > 0 ? totalProjected / projectedData.forecast.length : 0
  const hasFutureOneTimeExpenses = Object.values(projectedData.futureOneTimeExpensesByMonth).some(
    (arr) => arr.length > 0,
  )

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Previsão de Despesas</h2>
        <p className="text-muted-foreground">Visualize seus gastos futuros para um melhor planejamento</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Projeção para os Próximos {forecastMonths} Meses</CardTitle>
              <CardDescription>
                Estimativa baseada em despesas recorrentes, assinaturas e despesas pontuais agendadas.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer config={{}} className="aspect-[2/1]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={projectedData.forecast}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis tickFormatter={(value) => `R$${value}`} />
                    <Tooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Bar dataKey="total" fill="var(--color-primary)" name="Gasto Projetado" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Controls and Summary */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Configurar Previsão
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="forecast-months" className="flex items-center gap-2 mb-2">
                  <CalendarRange className="h-4 w-4" />
                  Período ({forecastMonths} meses)
                </Label>
                <Slider
                  id="forecast-months"
                  min={1}
                  max={12}
                  step={1}
                  value={[forecastMonths]}
                  onValueChange={(value) => setForecastMonths(value[0])}
                />
              </div>
              <div>
                <Label className="mb-2 block">Categorias</Label>
                <ScrollArea className="h-32 w-full rounded-md border p-2">
                  <div className="space-y-2">
                    {allCategories.map((category) => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox
                          id={`cat-${category}`}
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={() => handleCategoryChange(category)}
                        />
                        <Label htmlFor={`cat-${category}`} className="font-normal">
                          {category}
                        </Label>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Resumo da Previsão
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Projetado:</span>
                <span className="font-bold">R$ {totalProjected.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Média Mensal:</span>
                <span className="font-bold">R$ {averageMonthly.toFixed(2)}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Itens Recorrentes</CardTitle>
            <CardDescription>Despesas e assinaturas que se repetem e são usadas na projeção.</CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="items">
                <AccordionTrigger>Ver {projectedData.recurringItems.length} itens recorrentes</AccordionTrigger>
                <AccordionContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-2 pr-4">
                      {projectedData.recurringItems.map((item) => (
                        <div key={item.id} className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div>
                            <p className="font-medium">{"name" in item ? item.name : item.description}</p>
                            <p className="text-sm text-muted-foreground">{item.category}</p>
                          </div>
                          <Badge variant="secondary">
                            R${"price" in item ? item.price.toFixed(2) : item.amount.toFixed(2)}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Despesas Pontuais Futuras</CardTitle>
            <CardDescription>Despesas únicas agendadas para os próximos meses.</CardDescription>
          </CardHeader>
          <CardContent>
            {hasFutureOneTimeExpenses ? (
              <Accordion type="multiple" className="w-full">
                {Object.entries(projectedData.futureOneTimeExpensesByMonth)
                  .filter(([, expenses]) => expenses.length > 0)
                  .map(([month, expenses]) => (
                    <AccordionItem key={month} value={month}>
                      <AccordionTrigger>
                        {month} ({expenses.length} {expenses.length === 1 ? "despesa" : "despesas"})
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {expenses.map((exp) => (
                            <div key={exp.id} className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                              <div>
                                <p className="font-medium">{exp.description}</p>
                                <p className="text-sm text-muted-foreground">{exp.category}</p>
                              </div>
                              <Badge variant="outline">R$ {exp.amount.toFixed(2)}</Badge>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
              </Accordion>
            ) : (
              <div className="text-center text-muted-foreground py-10 flex flex-col items-center justify-center h-full">
                <PackageOpen className="h-10 w-10 mb-4" />
                <p className="font-medium">Nenhuma despesa pontual</p>
                <p className="text-sm">Não há despesas pontuais agendadas no período da previsão.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
