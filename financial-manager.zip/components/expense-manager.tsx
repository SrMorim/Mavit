"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Plus, Edit, Trash2, Receipt, DollarSign, Home, Repeat } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { DateInput } from "@/components/ui/date-input"

interface Expense {
  id: string
  description: string
  amount: number
  date: string
  category: string
  type: "recurring" | "one-time" | "fixed"
  frequency?: "daily" | "weekly" | "monthly" | "yearly"
}

interface ExpenseManagerProps {
  expenses: Expense[]
  setExpenses: (expenses: Expense[]) => void
}

export default function ExpenseManager({ expenses, setExpenses }: ExpenseManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null)
  const [customCategories, setCustomCategories] = useState<string[]>([])
  const [showCustomCategoryInput, setShowCustomCategoryInput] = useState(false)
  const [customCategoryName, setCustomCategoryName] = useState("")
  const [formData, setFormData] = useState({
    description: "",
    amount: "",
    date: "",
    category: "",
    type: "one-time" as "recurring" | "one-time" | "fixed",
    frequency: "monthly" as "daily" | "weekly" | "monthly" | "yearly",
  })

  const defaultCategories = [
    "Alimentação",
    "Transporte",
    "Moradia",
    "Saúde",
    "Educação",
    "Lazer",
    "Compras",
    "Serviços",
    "Outros",
  ]

  // Load custom categories from localStorage on component mount
  useEffect(() => {
    const savedCategories = localStorage.getItem("expenseCategories")
    if (savedCategories) {
      try {
        const categories = JSON.parse(savedCategories)
        setCustomCategories(categories)
      } catch (error) {
        console.error("Error loading expense categories:", error)
      }
    }
  }, [])

  // Save custom categories to localStorage whenever they change
  useEffect(() => {
    if (customCategories.length > 0) {
      localStorage.setItem("expenseCategories", JSON.stringify(customCategories))
    }
  }, [customCategories])

  const allCategories = [...defaultCategories, ...customCategories]

  // Helper function to format date for display (DD/MM/YYYY)
  const formatDateForDisplay = (dateString: string) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    // Add timezone offset to prevent off-by-one day errors
    const adjustedDate = new Date(date.valueOf() + date.getTimezoneOffset() * 60 * 1000)
    return adjustedDate.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  // Helper function to convert ISO date to input format (YYYY-MM-DD)
  const formatDateForInput = (dateString: string) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    return date.toISOString().split("T")[0]
  }

  // Helper function to validate and parse date input
  const parseDateInput = (inputValue: string) => {
    // Input comes as YYYY-MM-DD from date input
    return inputValue
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    let finalCategory = formData.category

    // Handle custom category
    if (formData.category === "custom" && customCategoryName.trim()) {
      finalCategory = customCategoryName.trim()
      if (!customCategories.includes(finalCategory)) {
        setCustomCategories((prev) => [...prev, finalCategory])
      }
    }

    const expenseData = {
      id: editingExpense?.id || Date.now().toString(),
      description: formData.description,
      amount: Number.parseFloat(formData.amount),
      date: formData.date,
      category: finalCategory,
      type: formData.type,
      frequency: formData.type === "recurring" ? formData.frequency : undefined,
    }

    if (editingExpense) {
      setExpenses(expenses.map((exp) => (exp.id === editingExpense.id ? expenseData : exp)))
    } else {
      setExpenses([...expenses, expenseData])
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({
      description: "",
      amount: "",
      date: "",
      category: "",
      type: "one-time",
      frequency: "monthly",
    })
    setEditingExpense(null)
    setIsDialogOpen(false)
    setShowCustomCategoryInput(false)
    setCustomCategoryName("")
  }

  const handleEdit = (expense: Expense) => {
    setEditingExpense(expense)
    setFormData({
      description: expense.description,
      amount: expense.amount.toString(),
      date: expense.date,
      category: expense.category,
      type: expense.type,
      frequency: expense.frequency || "monthly",
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setExpenses(expenses.filter((exp) => exp.id !== id))
  }

  const handleCategoryChange = (value: string) => {
    setFormData({ ...formData, category: value })
    if (value === "custom") {
      setShowCustomCategoryInput(true)
    } else {
      setShowCustomCategoryInput(false)
      setCustomCategoryName("")
    }
  }

  const groupedExpenses = expenses.reduce(
    (acc, expense) => {
      if (!acc[expense.type]) {
        acc[expense.type] = []
      }
      acc[expense.type].push(expense)
      return acc
    },
    {} as Record<string, Expense[]>,
  )

  const getMonthlyAmount = (expense: Expense) => {
    if (expense.type === "fixed") {
      return expense.amount
    }

    if (expense.type === "one-time") {
      // Check if the expense date is in the current month
      const expenseDate = new Date(expense.date)
      const currentDate = new Date()

      if (
        expenseDate.getMonth() === currentDate.getMonth() &&
        expenseDate.getFullYear() === currentDate.getFullYear()
      ) {
        return expense.amount
      }
      return 0
    }

    switch (expense.frequency) {
      case "daily":
        return expense.amount * 30
      case "weekly":
        return expense.amount * 4
      case "monthly":
        return expense.amount
      case "yearly":
        return expense.amount / 12
      default:
        return expense.amount
    }
  }

  const totalMonthlyExpenses = expenses.reduce((total, expense) => total + getMonthlyAmount(expense), 0)

  // Calculate totals by type for current month
  const fixedExpensesTotal = expenses
    .filter((exp) => exp.type === "fixed")
    .reduce((total, exp) => total + exp.amount, 0)

  const recurringExpensesTotal = expenses
    .filter((exp) => exp.type === "recurring")
    .reduce((total, exp) => total + getMonthlyAmount(exp), 0)

  const currentMonthOneTimeTotal = expenses
    .filter((exp) => exp.type === "one-time")
    .reduce((total, exp) => total + getMonthlyAmount(exp), 0)

  const expenseTypeConfig = {
    fixed: {
      title: "Despesas Fixas",
      icon: Home,
      color: "text-purple-600",
      description: "Despesas mensais fixas (aluguel, financiamentos, etc.)",
    },
    recurring: {
      title: "Despesas Recorrentes",
      icon: Repeat,
      color: "text-blue-600",
      description: "Despesas que se repetem com frequência variável",
    },
    "one-time": {
      title: "Despesas Pontuais",
      icon: Receipt,
      color: "text-green-600",
      description: "Despesas únicas ou esporádicas",
    },
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Despesas</h2>
          <p className="text-muted-foreground">Gerencie suas despesas fixas, recorrentes e pontuais</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingExpense(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Nova Despesa
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingExpense ? "Editar Despesa" : "Nova Despesa"}</DialogTitle>
              <DialogDescription>
                {editingExpense ? "Edite os dados da despesa" : "Adicione uma nova despesa para acompanhar"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2 form-field">
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Ex: Aluguel, Conta de luz, Almoço no restaurante..."
                    required
                    rows={2}
                  />
                </div>
                <div className="grid gap-2 form-field">
                  <Label htmlFor="amount">Valor</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>
                <div className="grid gap-2 form-field">
                  <Label htmlFor="date">Data de Vencimento</Label>
                  <DateInput
                    id="date"
                    value={formData.date}
                    onChange={(date) => setFormData({ ...formData, date: date })}
                    required
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Formato: DD/MM/AAAA
                    {formData.type === "fixed" && " - Data de vencimento mensal da despesa fixa"}
                    {formData.type === "recurring" && " - Data de referência para a despesa recorrente"}
                    {formData.type === "one-time" && " - Data específica da despesa pontual"}
                  </p>
                </div>
                <div className="grid gap-2 form-field">
                  <Label htmlFor="type">Tipo</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: "recurring" | "one-time" | "fixed") =>
                      setFormData({ ...formData, type: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fixed">
                        <div className="flex items-center gap-2">
                          <Home className="h-4 w-4 text-purple-600" />
                          <span>Fixa</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="recurring">
                        <div className="flex items-center gap-2">
                          <Repeat className="h-4 w-4 text-blue-600" />
                          <span>Recorrente</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="one-time">
                        <div className="flex items-center gap-2">
                          <Receipt className="h-4 w-4 text-green-600" />
                          <span>Pontual</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {formData.type === "fixed" && "Despesas mensais fixas como aluguel, financiamentos"}
                    {formData.type === "recurring" && "Despesas que se repetem com frequência variável"}
                    {formData.type === "one-time" && "Despesas únicas ou esporádicas"}
                  </p>
                </div>
                {formData.type === "recurring" && (
                  <div className="grid gap-2 form-field-slide-in">
                    <Label htmlFor="frequency">Frequência</Label>
                    <Select
                      value={formData.frequency}
                      onValueChange={(value: "daily" | "weekly" | "monthly" | "yearly") =>
                        setFormData({ ...formData, frequency: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Diária</SelectItem>
                        <SelectItem value="weekly">Semanal</SelectItem>
                        <SelectItem value="monthly">Mensal</SelectItem>
                        <SelectItem value="yearly">Anual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                <div className="grid gap-2 form-field">
                  <Label htmlFor="category">Categoria</Label>
                  <Select value={formData.category} onValueChange={handleCategoryChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      {allCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                      <SelectItem value="custom">+ Criar nova categoria</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {showCustomCategoryInput && (
                  <div className="grid gap-2 form-field-slide-in">
                    <Label htmlFor="customCategory">Nova Categoria</Label>
                    <Input
                      id="customCategory"
                      value={customCategoryName}
                      onChange={(e) => setCustomCategoryName(e.target.value)}
                      placeholder="Digite o nome da nova categoria"
                      required
                    />
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancelar
                </Button>
                <Button type="submit">{editingExpense ? "Salvar" : "Adicionar"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Enhanced Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Mensal</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R$ {totalMonthlyExpenses.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">{expenses.length} despesas registradas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesas Fixas</CardTitle>
            <Home className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{groupedExpenses.fixed?.length || 0}</div>
            <p className="text-xs text-muted-foreground">R$ {fixedExpensesTotal.toFixed(2)} mensais</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesas Recorrentes</CardTitle>
            <Repeat className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{groupedExpenses.recurring?.length || 0}</div>
            <p className="text-xs text-muted-foreground">R$ {recurringExpensesTotal.toFixed(2)} mensais</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pontuais (Mês Atual)</CardTitle>
            <Receipt className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{groupedExpenses["one-time"]?.length || 0}</div>
            <p className="text-xs text-muted-foreground">R$ {currentMonthOneTimeTotal.toFixed(2)} este mês</p>
          </CardContent>
        </Card>
      </div>

      {/* Expenses List */}
      <div className="space-y-6">
        {["fixed", "recurring", "one-time"].map((type) => {
          const typeExpenses = groupedExpenses[type] || []
          if (typeExpenses.length === 0) return null

          const config = expenseTypeConfig[type as keyof typeof expenseTypeConfig]
          const Icon = config.icon

          return (
            <div key={type}>
              <div className="flex items-center gap-2 mb-4">
                <Icon className={`h-5 w-5 ${config.color}`} />
                <h3 className="text-lg font-semibold">{config.title}</h3>
                <Badge variant="secondary" className="ml-2">
                  {typeExpenses.length}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-4">{config.description}</p>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {typeExpenses
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((expense) => {
                    const monthlyImpact = getMonthlyAmount(expense)
                    const isCurrentMonth = expense.type === "one-time" && monthlyImpact > 0

                    return (
                      <Card key={expense.id} className={`${isCurrentMonth ? "ring-2 ring-green-200" : ""}`}>
                        <CardHeader>
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <CardTitle className="text-lg flex items-center gap-2">
                                {expense.description}
                                <Icon className={`h-4 w-4 ${config.color}`} />
                              </CardTitle>
                              <CardDescription>{expense.category}</CardDescription>
                            </div>
                            <Badge
                              variant={
                                expense.type === "fixed"
                                  ? "default"
                                  : expense.type === "recurring"
                                    ? "secondary"
                                    : "outline"
                              }
                              className={
                                expense.type === "fixed"
                                  ? "bg-purple-600"
                                  : expense.type === "recurring"
                                    ? "bg-blue-600"
                                    : ""
                              }
                            >
                              {expense.type === "fixed"
                                ? "Fixa"
                                : expense.type === "recurring"
                                  ? "Recorrente"
                                  : "Pontual"}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Valor:</span>
                              <span className="font-medium">R$ {expense.amount.toFixed(2)}</span>
                            </div>
                            {expense.type === "recurring" && expense.frequency && (
                              <div className="flex justify-between">
                                <span className="text-sm text-muted-foreground">Frequência:</span>
                                <span className="font-medium">
                                  {expense.frequency === "daily"
                                    ? "Diária"
                                    : expense.frequency === "weekly"
                                      ? "Semanal"
                                      : expense.frequency === "monthly"
                                        ? "Mensal"
                                        : "Anual"}
                                </span>
                              </div>
                            )}
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Vencimento:</span>
                              <span className="font-medium">{formatDateForDisplay(expense.date)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-sm text-muted-foreground">Impacto mensal:</span>
                              <span className={`font-medium ${config.color}`}>
                                R$ {monthlyImpact.toFixed(2)}
                                {expense.type === "one-time" && monthlyImpact === 0 && (
                                  <span className="text-xs text-muted-foreground ml-1">(fora do mês atual)</span>
                                )}
                              </span>
                            </div>
                            {expense.type === "one-time" && isCurrentMonth && (
                              <div className="text-xs text-green-600 font-medium">✓ Incluído no cálculo mensal</div>
                            )}
                          </div>
                          <div className="flex gap-2 mt-4">
                            <Button variant="outline" size="sm" onClick={() => handleEdit(expense)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => handleDelete(expense.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
              </div>
            </div>
          )
        })}
      </div>

      {expenses.length === 0 && (
        <div className="text-center py-12">
          <Receipt className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
          <h3 className="text-lg font-medium mb-2">Nenhuma despesa cadastrada</h3>
          <p className="text-muted-foreground mb-4">Comece registrando suas despesas para ter controle financeiro</p>
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Despesa
          </Button>
        </div>
      )}
    </div>
  )
}
