"use client"

import { ChartTooltip } from "@/components/ui/chart"

import { useMemo } from "react"
import { BarChart3, DollarSign, PieChartIcon, PiggyBank, Plus, TrendingDown, TrendingUp } from "lucide-react"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

// Type definitions (should match the ones in app/page.tsx)
interface Subscription {
  id: string
  name: string
  price: number
  category: string
  billingCycle: "monthly" | "yearly"
  nextBilling: string
  status: "active" | "cancelled"
  priority: "high" | "medium" | "low"
}

interface Goal {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  deadline: string
  category: string
}

interface Expense {
  id: string
  description: string
  amount: number
  date: string
  category: string
  type: "recurring" | "one-time" | "fixed"
  frequency?: "daily" | "weekly" | "monthly" | "yearly"
}

interface ChartsViewProps {
  subscriptions: Subscription[]
  goals: Goal[]
  expenses: Expense[]
  monthlyIncome: number
}

// Helper function to calculate monthly equivalent of an expense
const getMonthlyExpenseAmount = (expense: Expense, currentMonth: number, currentYear: number): number => {
  const expenseDate = new Date(expense.date)
  if (expense.type === "fixed") {
    return expense.amount
  }
  if (expense.type === "one-time") {
    if (expenseDate.getMonth() === currentMonth && expenseDate.getFullYear() === currentYear) {
      return expense.amount
    }
    return 0
  }
  if (expense.type === "recurring") {
    switch (expense.frequency) {
      case "daily":
        return expense.amount * 30
      case "weekly":
        return expense.amount * 4
      case "monthly":
        return expense.amount
      case "yearly":
        return expense.amount / 12
      default:
        return 0
    }
  }
  return 0
}

export default function ChartsView({ subscriptions, goals, expenses, monthlyIncome }: ChartsViewProps) {
  const hasData = subscriptions.length > 0 || goals.length > 0 || expenses.length > 0

  const financialMetrics = useMemo(() => {
    const currentDate = new Date()
    const currentMonth = currentDate.getMonth()
    const currentYear = currentDate.getFullYear()

    const activeSubscriptions = subscriptions.filter((sub) => sub.status === "active")

    const monthlySubscriptionSpending = activeSubscriptions.reduce((total, sub) => {
      return total + (sub.billingCycle === "monthly" ? sub.price : sub.price / 12)
    }, 0)

    const monthlyExpenseSpending = expenses.reduce((total, exp) => {
      return total + getMonthlyExpenseAmount(exp, currentMonth, currentYear)
    }, 0)

    const totalMonthlySpending = monthlySubscriptionSpending + monthlyExpenseSpending

    const annualSavings = subscriptions
      .filter((s) => s.status === "cancelled")
      .reduce((total, sub) => {
        return total + (sub.billingCycle === "monthly" ? sub.price * 12 : sub.price)
      }, 0)

    const netMonthlyIncome = monthlyIncome - totalMonthlySpending

    // Data for Pie Chart
    const categorySpending = [...activeSubscriptions, ...expenses].reduce(
      (acc, item) => {
        let category: string
        let amount: number

        if ("price" in item) {
          // It's a Subscription
          category = item.category
          amount = item.billingCycle === "monthly" ? item.price : item.price / 12
        } else {
          // It's an Expense
          category = item.category
          amount = getMonthlyExpenseAmount(item, currentMonth, currentYear)
        }

        if (amount > 0) {
          acc[category] = (acc[category] || 0) + amount
        }
        return acc
      },
      {} as Record<string, number>,
    )

    // Data for Line Chart
    const spendingEvolutionData = [
      { month: "Jan", gastos: 120, renda: monthlyIncome },
      { month: "Fev", gastos: 135, renda: monthlyIncome },
      { month: "Mar", gastos: 140, renda: monthlyIncome },
      { month: "Abr", gastos: 125, renda: monthlyIncome },
      { month: "Mai", gastos: 150, renda: monthlyIncome },
      { month: "Jun", gastos: totalMonthlySpending, renda: monthlyIncome },
    ]

    // Data for Goals Chart
    const goalProgress = goals.map((goal) => ({
      name: goal.name,
      progress: (goal.currentAmount / goal.targetAmount) * 100,
      current: goal.currentAmount,
      target: goal.targetAmount,
    }))

    return {
      totalMonthlySpending,
      annualSavings,
      netMonthlyIncome,
      categorySpending,
      spendingEvolutionData,
      goalProgress,
    }
  }, [subscriptions, goals, expenses, monthlyIncome])

  if (!hasData) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Análise Visual</h2>
          <p className="text-muted-foreground">Visualize seus gastos e progresso das metas</p>
        </div>
        <div className="text-center py-16">
          <BarChart3 className="h-16 w-16 mx-auto mb-6 text-muted-foreground opacity-50" />
          <h3 className="text-xl font-medium mb-3">Nenhum dado para análise</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Para visualizar gráficos e análises, você precisa ter assinaturas, despesas ou metas cadastradas.
          </p>
          <div className="flex gap-3 justify-center">
            <Button variant="outline">
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Assinatura
            </Button>
            <Button variant="outline">
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Despesa
            </Button>
            <Button variant="outline">
              <Plus className="h-4 w-4 mr-2" />
              Criar Meta
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const pieChartData = Object.entries(financialMetrics.categorySpending).map(([name, value], index) => ({
    name,
    value,
    fill: `hsl(var(--chart-${(index % 5) + 1}))`,
  }))

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Análise Visual</h2>
        <p className="text-muted-foreground">Visualize seus gastos e progresso das metas</p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resumo Mensal</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">
              -R$ {financialMetrics.totalMonthlySpending.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">Gastos com assinaturas e despesas</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Economia Anual</CardTitle>
            <PiggyBank className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">R$ {financialMetrics.annualSavings.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Com assinaturas canceladas</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo Líquido Mensal</CardTitle>
            <DollarSign
              className={`h-4 w-4 ${financialMetrics.netMonthlyIncome >= 0 ? "text-green-500" : "text-red-500"}`}
            />
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${
                financialMetrics.netMonthlyIncome >= 0 ? "text-green-500" : "text-red-500"
              }`}
            >
              R$ {financialMetrics.netMonthlyIncome.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground">Renda mensal vs. gastos</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Spending by Category Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Gastos por Categoria</CardTitle>
            <CardDescription>Distribuição dos seus gastos mensais</CardDescription>
          </CardHeader>
          <CardContent>
            {pieChartData.length > 0 ? (
              <ChartContainer config={{}} className="aspect-square">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieChartData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {pieChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <ChartTooltip content={<ChartTooltipContent nameKey="name" hideLabel />} />
                  </PieChart>
                </ResponsiveContainer>
              </ChartContainer>
            ) : (
              <div className="flex flex-col items-center justify-center py-12">
                <PieChartIcon className="h-12 w-12 text-muted-foreground opacity-50 mb-4" />
                <p className="text-sm text-muted-foreground text-center">
                  Adicione despesas ou assinaturas para ver o gráfico.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Spending Evolution Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Evolução Financeira</CardTitle>
            <CardDescription>Histórico de renda vs. gastos mensais</CardDescription>
          </CardHeader>
          <CardContent>
            {financialMetrics.totalMonthlySpending > 0 || monthlyIncome > 0 ? (
              <ChartContainer
                config={{
                  gastos: { label: "Gastos", color: "hsl(var(--chart-1))" },
                  renda: { label: "Renda", color: "hsl(var(--chart-2))" },
                }}
                className="aspect-[4/3]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={financialMetrics.spendingEvolutionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Line type="monotone" dataKey="gastos" stroke="var(--color-gastos)" strokeWidth={2} name="Gastos" />
                    {monthlyIncome > 0 && (
                      <Line type="monotone" dataKey="renda" stroke="var(--color-renda)" strokeWidth={2} name="Renda" />
                    )}
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            ) : (
              <div className="flex flex-col items-center justify-center py-12">
                <TrendingUp className="h-12 w-12 text-muted-foreground opacity-50 mb-4" />
                <p className="text-sm text-muted-foreground text-center">
                  Adicione sua renda e despesas para ver a evolução.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Goals Progress Chart */}
      {goals.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Progresso das Metas</CardTitle>
            <CardDescription>Acompanhe o progresso de todas as suas metas</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{ progress: { label: "Progresso", color: "hsl(var(--chart-3))" } }}
              className="aspect-[2/1]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={financialMetrics.goalProgress}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis unit="%" />
                  <Tooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="progress" fill="var(--color-progress)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
