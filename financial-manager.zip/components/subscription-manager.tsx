"use client"

import type React from "react"
import { CreditCard } from "lucide-react"

import { useState, useEffect } from "react"
import { Plus, Edit, Trash2, AlertCircle, Circle, Minus, Loader2, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DateInput } from "@/components/ui/date-input"

interface Subscription {
  id: string
  name: string
  price: number
  category: string
  billingCycle: "monthly" | "yearly"
  nextBilling: string
  status: "active" | "cancelled"
  priority: "high" | "medium" | "low"
}

interface SubscriptionManagerProps {
  subscriptions: Subscription[]
  setSubscriptions: (subscriptions: Subscription[]) => void
}

export default function SubscriptionManager({ subscriptions, setSubscriptions }: SubscriptionManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingSubscription, setEditingSubscription] = useState<Subscription | null>(null)
  const [customCategories, setCustomCategories] = useState<string[]>([])
  const [showCustomCategoryInput, setShowCustomCategoryInput] = useState(false)
  const [customCategoryName, setCustomCategoryName] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    category: "",
    billingCycle: "monthly" as "monthly" | "yearly",
    nextBilling: "",
    priority: "medium" as "high" | "medium" | "low",
  })

  const defaultCategories = ["Entretenimento", "Produtividade", "Saúde", "Educação", "Outros"]

  // Load custom categories from localStorage on component mount
  useEffect(() => {
    const savedCategories = localStorage.getItem("subscriptionCategories")
    if (savedCategories) {
      try {
        const categories = JSON.parse(savedCategories)
        setCustomCategories(categories)
      } catch (error) {
        console.error("Error loading subscription categories:", error)
      }
    }
  }, [])

  // Save custom categories to localStorage whenever they change
  useEffect(() => {
    if (customCategories.length > 0) {
      localStorage.setItem("subscriptionCategories", JSON.stringify(customCategories))
    }
  }, [customCategories])

  const allCategories = [...defaultCategories, ...customCategories]

  const priorityOptions = [
    { value: "high", label: "Alta", color: "text-red-600", icon: AlertCircle },
    { value: "medium", label: "Média", color: "text-yellow-600", icon: Circle },
    { value: "low", label: "Baixa", color: "text-green-600", icon: Minus },
  ]

  const getPriorityConfig = (priority: string) => {
    return priorityOptions.find((p) => p.value === priority) || priorityOptions[1]
  }

  // Helper function to format date for display (DD/MM/YYYY)
  const formatDateForDisplay = (dateString: string) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    // Add timezone offset to prevent off-by-one day errors
    const adjustedDate = new Date(date.valueOf() + date.getTimezoneOffset() * 60 * 1000)
    return adjustedDate.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitSuccess(false)

    // Simulate API call delay for better UX
    await new Promise((resolve) => setTimeout(resolve, 800))

    let finalCategory = formData.category

    // Handle custom category
    if (formData.category === "custom" && customCategoryName.trim()) {
      finalCategory = customCategoryName.trim()
      if (!customCategories.includes(finalCategory)) {
        setCustomCategories((prev) => [...prev, finalCategory])
      }
    }

    const subscriptionData = {
      id: editingSubscription?.id || Date.now().toString(),
      name: formData.name,
      price: Number.parseFloat(formData.price),
      category: finalCategory,
      billingCycle: formData.billingCycle,
      nextBilling: formData.nextBilling,
      status: "active" as const,
      priority: formData.priority,
    }

    if (editingSubscription) {
      setSubscriptions(subscriptions.map((sub) => (sub.id === editingSubscription.id ? subscriptionData : sub)))
    } else {
      setSubscriptions([...subscriptions, subscriptionData])
    }

    setSubmitSuccess(true)

    // Reset form after success animation
    setTimeout(() => {
      resetForm()
    }, 1000)
  }

  const resetForm = () => {
    setFormData({
      name: "",
      price: "",
      category: "",
      billingCycle: "monthly",
      nextBilling: "",
      priority: "medium",
    })
    setEditingSubscription(null)
    setIsDialogOpen(false)
    setShowCustomCategoryInput(false)
    setCustomCategoryName("")
    setIsSubmitting(false)
    setSubmitSuccess(false)
  }

  const handleEdit = (subscription: Subscription) => {
    setEditingSubscription(subscription)
    setFormData({
      name: subscription.name,
      price: subscription.price.toString(),
      category: subscription.category,
      billingCycle: subscription.billingCycle,
      nextBilling: subscription.nextBilling,
      priority: subscription.priority,
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setSubscriptions(subscriptions.filter((sub) => sub.id !== id))
  }

  const toggleStatus = (id: string) => {
    setSubscriptions(
      subscriptions.map((sub) =>
        sub.id === id ? { ...sub, status: sub.status === "active" ? "cancelled" : "active" } : sub,
      ),
    )
  }

  const handleCategoryChange = (value: string) => {
    setFormData({ ...formData, category: value })
    if (value === "custom") {
      setShowCustomCategoryInput(true)
    } else {
      setShowCustomCategoryInput(false)
      setCustomCategoryName("")
    }
  }

  const groupedSubscriptions = subscriptions.reduce(
    (acc, sub) => {
      if (!acc[sub.priority]) {
        acc[sub.priority] = []
      }
      acc[sub.priority].push(sub)
      return acc
    },
    {} as Record<string, Subscription[]>,
  )

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex justify-between items-center">
        <div className="animate-slide-in-left">
          <h2 className="text-2xl font-bold">Assinaturas</h2>
          <p className="text-muted-foreground">Gerencie suas assinaturas mensais e anuais</p>
        </div>
        <div className="animate-slide-in-right">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => setEditingSubscription(null)} className="btn-animate">
                <Plus className="h-4 w-4 mr-2" />
                Nova Assinatura
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md modal-content">
              <DialogHeader>
                <DialogTitle>{editingSubscription ? "Editar Assinatura" : "Nova Assinatura"}</DialogTitle>
                <DialogDescription>
                  {editingSubscription
                    ? "Edite os dados da assinatura"
                    : "Adicione uma nova assinatura para acompanhar"}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="name">Nome</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Ex: Netflix, Spotify..."
                      required
                      className="input-focus"
                      disabled={isSubmitting}
                    />
                  </div>
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="price">Preço</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      placeholder="0.00"
                      required
                      className="input-focus"
                      disabled={isSubmitting}
                    />
                  </div>
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="category">Categoria</Label>
                    <Select value={formData.category} onValueChange={handleCategoryChange} disabled={isSubmitting}>
                      <SelectTrigger className="input-focus">
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {allCategories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                        <SelectItem value="custom">+ Criar nova categoria</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {showCustomCategoryInput && (
                    <div className="grid gap-2 form-field-slide-in">
                      <Label htmlFor="customCategory">Nova Categoria</Label>
                      <Input
                        id="customCategory"
                        value={customCategoryName}
                        onChange={(e) => setCustomCategoryName(e.target.value)}
                        placeholder="Digite o nome da nova categoria"
                        required
                        className="input-focus"
                        disabled={isSubmitting}
                      />
                    </div>
                  )}
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="priority">Nível de Prioridade</Label>
                    <Select
                      value={formData.priority}
                      onValueChange={(value: "high" | "medium" | "low") =>
                        setFormData({ ...formData, priority: value })
                      }
                      disabled={isSubmitting}
                    >
                      <SelectTrigger className="input-focus">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {priorityOptions.map((option) => {
                          const Icon = option.icon
                          return (
                            <SelectItem key={option.value} value={option.value}>
                              <div className="flex items-center gap-2">
                                <Icon className={`h-4 w-4 ${option.color}`} />
                                <span>{option.label}</span>
                              </div>
                            </SelectItem>
                          )
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="billingCycle">Ciclo de Cobrança</Label>
                    <Select
                      value={formData.billingCycle}
                      onValueChange={(value: "monthly" | "yearly") => setFormData({ ...formData, billingCycle: value })}
                      disabled={isSubmitting}
                    >
                      <SelectTrigger className="input-focus">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">Mensal</SelectItem>
                        <SelectItem value="yearly">Anual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="nextBilling">Próxima Cobrança</Label>
                    <DateInput
                      id="nextBilling"
                      value={formData.nextBilling}
                      onChange={(date) => setFormData({ ...formData, nextBilling: date })}
                      required
                      disabled={isSubmitting}
                    />
                    <p className="text-xs text-muted-foreground">Formato: DD/MM/AAAA</p>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={resetForm}
                    disabled={isSubmitting}
                    className="btn-animate bg-transparent"
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className={`btn-animate ${submitSuccess ? "success-glow" : ""}`}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Salvando...
                      </>
                    ) : submitSuccess ? (
                      <>
                        <Check className="h-4 w-4 mr-2" />
                        Salvo!
                      </>
                    ) : editingSubscription ? (
                      "Salvar"
                    ) : (
                      "Adicionar"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Subscriptions grouped by priority */}
      <div className="space-y-6">
        {priorityOptions.map((priorityConfig, index) => {
          const prioritySubscriptions = groupedSubscriptions[priorityConfig.value] || []
          if (prioritySubscriptions.length === 0) return null

          const Icon = priorityConfig.icon

          return (
            <div key={priorityConfig.value} className={`animate-fade-in stagger-${index + 1}`}>
              <div className="flex items-center gap-2 mb-4">
                <Icon className={`h-5 w-5 ${priorityConfig.color} animate-heartbeat`} />
                <h3 className="text-lg font-semibold">Prioridade {priorityConfig.label}</h3>
                <Badge variant="secondary" className="ml-2 badge-animate">
                  {prioritySubscriptions.length}
                </Badge>
              </div>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {prioritySubscriptions.map((subscription, subIndex) => (
                  <Card
                    key={subscription.id}
                    className={`card-hover animate-scale-in ${subscription.status === "cancelled" ? "opacity-60" : ""}`}
                    style={{ animationDelay: `${subIndex * 0.1}s` }}
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <CardTitle className="text-lg flex items-center gap-2">
                            {subscription.name}
                            <Icon className={`h-4 w-4 ${priorityConfig.color}`} />
                          </CardTitle>
                          <CardDescription>{subscription.category}</CardDescription>
                        </div>
                        <Badge
                          variant={subscription.status === "active" ? "default" : "secondary"}
                          className="badge-animate"
                        >
                          {subscription.status === "active" ? "Ativa" : "Cancelada"}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Preço:</span>
                          <span className="font-medium">R$ {subscription.price.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Ciclo:</span>
                          <span className="font-medium">
                            {subscription.billingCycle === "monthly" ? "Mensal" : "Anual"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Prioridade:</span>
                          <Badge
                            variant="outline"
                            className={`text-xs badge-animate ${
                              subscription.priority === "high"
                                ? "border-red-200 text-red-700"
                                : subscription.priority === "medium"
                                  ? "border-yellow-200 text-yellow-700"
                                  : "border-green-200 text-green-700"
                            }`}
                          >
                            {priorityConfig.label}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Próxima cobrança:</span>
                          <span className="font-medium">{formatDateForDisplay(subscription.nextBilling)}</span>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(subscription)}
                          className="btn-animate"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleStatus(subscription.id)}
                          className="btn-animate"
                        >
                          {subscription.status === "active" ? "Cancelar" : "Reativar"}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(subscription.id)}
                          className="btn-animate"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )
        })}
      </div>

      {subscriptions.length === 0 && (
        <div className="text-center py-12 animate-fade-in">
          <CreditCard className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50 animate-bounce" />
          <h3 className="text-lg font-medium mb-2">Nenhuma assinatura cadastrada</h3>
          <p className="text-muted-foreground mb-4">Comece adicionando sua primeira assinatura</p>
          <Button onClick={() => setIsDialogOpen(true)} className="btn-animate">
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Assinatura
          </Button>
        </div>
      )}
    </div>
  )
}
