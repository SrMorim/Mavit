"use client"

import type React from "react"

import { useState } from "react"
import { Plus, Edit, Trash2, Target, Loader2, Check, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DateInput } from "@/components/ui/date-input"

interface Goal {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  deadline: string
  category: string
}

interface GoalManagerProps {
  goals: Goal[]
  setGoals: (goals: Goal[]) => void
}

export default function GoalManager({ goals, setGoals }: GoalManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false)
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null)
  const [updateAmount, setUpdateAmount] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [updateSuccess, setUpdateSuccess] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    targetAmount: "",
    currentAmount: "",
    deadline: "",
    category: "",
  })

  const categories = ["Reserva", "Lazer", "Investimento", "Educação", "Outros"]

  // Helper function to format date for display (DD/MM/YYYY)
  const formatDateForDisplay = (dateString: string) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    // Add timezone offset to prevent off-by-one day errors
    const adjustedDate = new Date(date.valueOf() + date.getTimezoneOffset() * 60 * 1000)
    return adjustedDate.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  // Helper function to convert ISO date to input format (YYYY-MM-DD)
  const formatDateForInput = (dateString: string) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    return date.toISOString().split("T")[0]
  }

  // Helper function to validate and parse date input
  const parseDateInput = (inputValue: string) => {
    // Input comes as YYYY-MM-DD from date input
    return inputValue
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitSuccess(false)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 800))

    const goalData = {
      id: editingGoal?.id || Date.now().toString(),
      name: formData.name,
      targetAmount: Number.parseFloat(formData.targetAmount),
      currentAmount: Number.parseFloat(formData.currentAmount),
      deadline: formData.deadline,
      category: formData.category,
    }

    if (editingGoal) {
      setGoals(goals.map((goal) => (goal.id === editingGoal.id ? goalData : goal)))
    } else {
      setGoals([...goals, goalData])
    }

    setSubmitSuccess(true)

    setTimeout(() => {
      resetForm()
    }, 1000)
  }

  const resetForm = () => {
    setFormData({
      name: "",
      targetAmount: "",
      currentAmount: "",
      deadline: "",
      category: "",
    })
    setEditingGoal(null)
    setIsDialogOpen(false)
    setIsSubmitting(false)
    setSubmitSuccess(false)
  }

  const handleEdit = (goal: Goal) => {
    setEditingGoal(goal)
    setFormData({
      name: goal.name,
      targetAmount: goal.targetAmount.toString(),
      currentAmount: goal.currentAmount.toString(),
      deadline: goal.deadline,
      category: goal.category,
    })
    setIsDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    setGoals(goals.filter((goal) => goal.id !== id))
  }

  const handleUpdateAmount = (goal: Goal) => {
    setEditingGoal(goal)
    setUpdateAmount(goal.currentAmount.toString())
    setIsUpdateDialogOpen(true)
  }

  const submitUpdateAmount = async () => {
    setIsUpdating(true)
    setUpdateSuccess(false)

    await new Promise((resolve) => setTimeout(resolve, 600))

    if (editingGoal) {
      setGoals(
        goals.map((goal) =>
          goal.id === editingGoal.id ? { ...goal, currentAmount: Number.parseFloat(updateAmount) } : goal,
        ),
      )
    }

    setUpdateSuccess(true)

    setTimeout(() => {
      setIsUpdateDialogOpen(false)
      setEditingGoal(null)
      setUpdateAmount("")
      setIsUpdating(false)
      setUpdateSuccess(false)
    }, 1000)
  }

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex justify-between items-center">
        <div className="animate-slide-in-left">
          <h2 className="text-2xl font-bold">Metas Financeiras</h2>
          <p className="text-muted-foreground">Defina e acompanhe suas metas de economia</p>
        </div>
        <div className="animate-slide-in-right">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => setEditingGoal(null)} className="btn-animate">
                <Plus className="h-4 w-4 mr-2" />
                Nova Meta
              </Button>
            </DialogTrigger>
            <DialogContent className="modal-content">
              <DialogHeader>
                <DialogTitle>{editingGoal ? "Editar Meta" : "Nova Meta"}</DialogTitle>
                <DialogDescription>
                  {editingGoal ? "Edite os dados da meta" : "Crie uma nova meta financeira para acompanhar"}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="name">Nome da Meta</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Ex: Reserva de emergência, Viagem..."
                      required
                      className="input-focus"
                      disabled={isSubmitting}
                    />
                  </div>
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="targetAmount">Valor Objetivo</Label>
                    <Input
                      id="targetAmount"
                      type="number"
                      step="0.01"
                      value={formData.targetAmount}
                      onChange={(e) => setFormData({ ...formData, targetAmount: e.target.value })}
                      placeholder="0.00"
                      required
                      className="input-focus"
                      disabled={isSubmitting}
                    />
                  </div>
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="currentAmount">Valor Atual</Label>
                    <Input
                      id="currentAmount"
                      type="number"
                      step="0.01"
                      value={formData.currentAmount}
                      onChange={(e) => setFormData({ ...formData, currentAmount: e.target.value })}
                      placeholder="0.00"
                      required
                      className="input-focus"
                      disabled={isSubmitting}
                    />
                  </div>
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="category">Categoria</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                      disabled={isSubmitting}
                    >
                      <SelectTrigger className="input-focus">
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2 form-field">
                    <Label htmlFor="deadline">Prazo</Label>
                    <DateInput
                      id="deadline"
                      value={formData.deadline}
                      onChange={(date) => setFormData({ ...formData, deadline: date })}
                      required
                      disabled={isSubmitting}
                    />
                    <p className="text-xs text-muted-foreground">Formato: DD/MM/AAAA</p>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={resetForm}
                    disabled={isSubmitting}
                    className="btn-animate bg-transparent"
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className={`btn-animate ${submitSuccess ? "success-glow" : ""}`}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Salvando...
                      </>
                    ) : submitSuccess ? (
                      <>
                        <Check className="h-4 w-4 mr-2" />
                        Salvo!
                      </>
                    ) : editingGoal ? (
                      "Salvar"
                    ) : (
                      "Criar Meta"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Dialog para atualizar valor */}
      <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
        <DialogContent className="modal-content">
          <DialogHeader>
            <DialogTitle>Atualizar Progresso</DialogTitle>
            <DialogDescription>Atualize o valor atual da meta "{editingGoal?.name}"</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2 form-field">
              <Label htmlFor="updateAmount">Novo Valor</Label>
              <Input
                id="updateAmount"
                type="number"
                step="0.01"
                value={updateAmount}
                onChange={(e) => setUpdateAmount(e.target.value)}
                placeholder="0.00"
                className="input-focus"
                disabled={isUpdating}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsUpdateDialogOpen(false)}
              disabled={isUpdating}
              className="btn-animate"
            >
              Cancelar
            </Button>
            <Button
              onClick={submitUpdateAmount}
              disabled={isUpdating}
              className={`btn-animate ${updateSuccess ? "success-glow" : ""}`}
            >
              {isUpdating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Atualizando...
                </>
              ) : updateSuccess ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Atualizado!
                </>
              ) : (
                "Atualizar"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="grid gap-4 md:grid-cols-2">
        {goals.map((goal, index) => {
          const progress = (goal.currentAmount / goal.targetAmount) * 100
          const isCompleted = progress >= 100
          const daysLeft = Math.ceil((new Date(goal.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))

          return (
            <Card
              key={goal.id}
              className={`card-hover animate-scale-in ${isCompleted ? "success-glow" : ""}`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Target
                        className={`h-5 w-5 ${isCompleted ? "text-green-600 animate-bounce" : "animate-heartbeat"}`}
                      />
                      {goal.name}
                    </CardTitle>
                    <CardDescription>{goal.category}</CardDescription>
                  </div>
                  <div className="text-right">
                    <div className={`text-2xl font-bold ${isCompleted ? "text-green-600" : ""}`}>
                      {progress.toFixed(1)}%
                    </div>
                    <div className="text-sm text-muted-foreground">{daysLeft > 0 ? `${daysLeft} dias` : "Vencido"}</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Progress
                    value={Math.min(progress, 100)}
                    className={`h-2 progress-animate ${isCompleted ? "bg-green-100" : ""}`}
                  />

                  <div className="flex justify-between text-sm">
                    <span>R$ {goal.currentAmount.toFixed(2)}</span>
                    <span>R$ {goal.targetAmount.toFixed(2)}</span>
                  </div>

                  <div className="text-sm text-muted-foreground">Prazo: {formatDateForDisplay(goal.deadline)}</div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleUpdateAmount(goal)}
                      className="btn-animate"
                    >
                      <TrendingUp className="h-4 w-4 mr-1" />
                      Atualizar Valor
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleEdit(goal)} className="btn-animate">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleDelete(goal.id)} className="btn-animate">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {goals.length === 0 && (
        <div className="text-center py-12 animate-fade-in">
          <Target className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50 animate-bounce" />
          <h3 className="text-lg font-medium mb-2">Nenhuma meta financeira cadastrada</h3>
          <p className="text-muted-foreground mb-4">Defina suas metas de economia e acompanhe seu progresso</p>
          <Button onClick={() => setIsDialogOpen(true)} className="btn-animate">
            <Plus className="h-4 w-4 mr-2" />
            Criar Primeira Meta
          </Button>
        </div>
      )}
    </div>
  )
}
